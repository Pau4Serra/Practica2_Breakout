class setup {
    constructor() {
        
    }
}